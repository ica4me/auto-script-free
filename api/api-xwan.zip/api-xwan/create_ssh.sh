#!/bin/bash
# ==========================================
# Script API Create SSH | Smart DB & Quota Enabled
# ==========================================
export TERM=xterm
export PATH="/usr/sbin:/usr/bin:/sbin:/bin"

user=$1
Pass=$2
iplimit=$3
masaaktif=$4
# Perbaikan: Menangkap parameter ke-5 (Quota) dari API
Quota=$5 

Login="${user}SSH$(</dev/urandom tr -dc A-Z0-9 | head -c3)"
IP=$(curl -sS ipv4.icanhazip.com 2>/dev/null)

# --- BAGIAN BYPASS LISENSI ---
checking_sc() {
    echo "License ByPass... SUCCESS!"
}
checking_sc
# -----------------------------

# Cek & Buat Grup User
if getent group "$Login" > /dev/null; then
    GROUP_OPTION="-g $Login"
else
    /usr/sbin/groupadd "$Login"
    GROUP_OPTION="-g $Login"
fi

if egrep "^$Login" /etc/passwd >/dev/null; then
    echo "User $Login sudah ada."
    exit 1
fi

ISP=$(cat /etc/xray/isp 2>/dev/null)
CITY=$(cat /etc/xray/city 2>/dev/null)
domain=$(cat /etc/xray/domain 2>/dev/null)
NS=$(cat /etc/xray/dns 2>/dev/null)
PUB=$(cat /etc/slowdns/server.pub 2>/dev/null)

tgl=$(date -d "$masaaktif days" +"%d")
bln=$(date -d "$masaaktif days" +"%b")
thn=$(date -d "$masaaktif days" +"%Y")
expe="$tgl $bln, $thn"
tnggl="$(date +"%d %b, %Y")"
exp_db=$(date -d "$masaaktif days" +"%Y-%m-%d")

# ================= EKSEKUSI PEMBUATAN USER OS =================
/usr/sbin/useradd -e "$(date -d "$masaaktif days" +"%Y-%m-%d")" -s /bin/false -M $GROUP_OPTION "$Login"
echo -e "$Pass\n$Pass" | passwd "$Login" &> /dev/null

if ! egrep "^$Login" /etc/passwd >/dev/null; then
    echo "Gagal membuat user $Login. Periksa log untuk detail."
    exit 1
fi

# ================= LIMIT IP =================
if [[ $iplimit -gt 0 ]]; then
    mkdir -p /etc/kyt/limit/ssh/ip/
    echo -e "$iplimit" > /etc/kyt/limit/ssh/ip/"$Login"
fi

# ================= LIMIT QUOTA (PERBAIKAN) =================
if [ -z "$Quota" ] || [ "$Quota" == "undefined" ]; then Quota="0"; fi
c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))

mkdir -p /etc/ssh
if [[ ${c} != "0" ]]; then
  echo "${d}" > /etc/ssh/${Login}
fi

# ================= SAVE TO DATABASE =================
sed -i "/\b${Login}\b/d" /etc/ssh/.ssh.db 2>/dev/null
# Format database standar sistem Anda: #ssh# user pass quota iplimit exp
echo "#ssh# ${Login} ${Pass} ${Quota} ${iplimit} ${exp_db}" >> /etc/ssh/.ssh.db

# ================= FORMAT OPENCLASH & OVPN =================
mkdir -p /var/www/html
cat > /var/www/html/ssh-$Login.txt <<-END
-----------------------------------------
SSH / OpenVPN Account
-----------------------------------------
Host             : $domain
IP               : $IP
Username         : $Login
Password         : $Pass
-----------------------------------------
Limit Ip         : ${iplimit} IP
Limit Quota      : ${Quota} GB
Host Slowdns     : ${NS}
Pub Key          : ${PUB}
Port OpenSSH     : 22
Port DNS         : 53, 2222
Port SSH UDP     : 1-65535
Port Dropbear    : 22, 109
Port SSH WS      : 80,8080,2086,8880
Port SSH WS SSL  : 443,8443
Port SSL/TLS     : 443
BadVPN UDP       : 7100, 7200, 7300
-----------------------------------------
HTTP CUSTOM      : $domain:1-65535@$Login:$Pass
-----------------------------------------
Payload          : GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]
-----------------------------------------
Save Link Account: https://$domain:81/ssh-$Login.txt
-----------------------------------------
Aktif Selama     : $masaaktif Hari
Dibuat Pada      : $tnggl
Berakhir Pada    : $expe
-----------------------------------------
END

# ================= NOTIFIKASI TELEGRAM =================
function notif_ssh() {
    CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 3)
    KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 2)
    export TIME="10"
    export URL="https://api.telegram.org/bot$KEY/sendMessage"
    sensor=$(echo "$Login" | sed 's/\(.\{3\}\).*/\1xxx/')
    
    if [[ -n "$KEY" && -n "$CHATID" ]]; then
        TEXT="<b>======================</b>
<b>PREMIUM SSH GENERATED API</b>
<b>======================</b>
<b>» ISP :</b> <code>${ISP}</code>
<b>» Limit Quota :</b> <code>${Quota} GB</code>
<b>» Limit Login :</b> <code>${iplimit} Device</code>
<b>» Username :</b> <code>${sensor}</code>
<b>» Duration :</b> <code>${masaaktif} Days</code>
<b>======================</b>"
        curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" "$URL" >/dev/null
    fi
}
notif_ssh

# ================= OUTPUT UNTUK API.JS =================
# (JANGAN MENGUBAH TEKS SEBELAH KIRI AGAR PARSING REGEX API.JS TIDAK ERROR)
echo -e " Remark       : $Login "
echo -e " Password     : $Pass "
echo -e " Limit Ip     : ${iplimit} IP"
echo -e " Limit Quota  : ${Quota} GB"
echo -e " Domain       : $domain "
echo -e " Ns Domain    : $NS  "
echo -e " OpenSSH      : 443, 80, 22 "
echo -e " Port UDP     : 1-65535 "
echo -e " Pub Key      : $PUB "
echo -e " SSH WS       : 80,8080,8880,2086 "
echo -e " SSL/TLS      : 443 "
echo -e " OVPN UDP     : 2200 "
echo -e " ISP          : $ISP"
echo -e " Port 80      : $domain:80@$Login:$Pass "
echo -e " Port 443     : $domain:443@$Login:$Pass "
echo -e " Udp Custom   : $domain:1-65535@$Login:$Pass"
echo -e " OpenVpn      : https://$domain:81/ "
echo -e " Account      : https://$domain:81/ssh-$Login.txt "
echo -e " Expiry in    : $expe "
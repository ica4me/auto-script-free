#!/bin/bash
pup="30"
USER_DB="/etc/zivpn/users.db.json"
CONFIG_FILE="/etc/zivpn/config.json"
domain=$(cat /etc/xray/domain 2>/dev/null)

Login="TrialZI$(</dev/urandom tr -dc A-Z0-9 | head -c3)"
password=$(</dev/urandom tr -dc a-zA-Z0-9 | head -c6)
expiry_timestamp=$(date -d "+$pup minutes" +%s)

new_user_json=$(jq -n --arg user "$Login" --arg pass "$password" --argjson expiry "$expiry_timestamp" '{username: $user, password: $pass, expiry_timestamp: $expiry}')
jq --argjson new_user "$new_user_json" '. += [$new_user]' "$USER_DB" > "$USER_DB.tmp" && mv "$USER_DB.tmp" "$USER_DB"

passwords_json=$(jq '[.[].password]' "$USER_DB")
jq --argjson passwords "$passwords_json" '.auth.config = $passwords | .config = $passwords' "$CONFIG_FILE" > "$CONFIG_FILE.tmp" && mv "$CONFIG_FILE.tmp" "$CONFIG_FILE"
systemctl restart zivpn.service > /dev/null 2>&1

# Background RAM Auto-Killer
(
    sleep $((pup * 60))
    jq --arg user "$Login" 'del(.[] | select(.username == $user))' "$USER_DB" > "$USER_DB.tmp" && mv "$USER_DB.tmp" "$USER_DB"
    passwords_json=$(jq '[.[].password]' "$USER_DB")
    jq --argjson passwords "$passwords_json" '.auth.config = $passwords | .config = $passwords' "$CONFIG_FILE" > "$CONFIG_FILE.tmp" && mv "$CONFIG_FILE.tmp" "$CONFIG_FILE"
    systemctl restart zivpn.service > /dev/null 2>&1
) &

clear
echo -e " Remark       : $Login "
echo -e " Password     : $password "
echo -e " Domain       : $domain "
echo -e " Expiry in    : $pup Minutes "
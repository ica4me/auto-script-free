#!/bin/bash
# ==========================================
# Script API Create NOOBZVPN | Smart DB
# ==========================================
user=$1
Pass=$2
iplimit=$3
masaaktif=$4
Quota=$5

Login="${user}NBZ$(</dev/urandom tr -dc A-Z0-9 | head -c3)"
IP=$(curl -sS ipv4.icanhazip.com 2>/dev/null)
domain=$(cat /etc/xray/domain 2>/dev/null)

# Pembuatan User OS & Noobz
if ! grep -q "/bin/false" /etc/shells; then echo "/bin/false" >> /etc/shells; fi
useradd -e $(date -d "$masaaktif days" +"%Y-%m-%d") -s /bin/false -M $Login
echo "$Login:$Pass" | chpasswd
chage -m 0 -M 99999 -W 7 "$Login" 2>/dev/null

# Command Inti NoobzVPN
if command -v noobzvpns &> /dev/null; then
    noobzvpns --add-user $Login $Pass --expired-user $Login $masaaktif
fi

# Limit IP & Quota (Disimpan di folder ssh karena sharing port)
if [[ $iplimit -gt 0 ]]; then
    mkdir -p /etc/kyt/limit/ssh/ip/
    echo -e "$iplimit" > /etc/kyt/limit/ssh/ip/$Login
fi

# Database SSH/Noobz Gabungan
tgl=$(date -d "$masaaktif days" +"%d %b, %Y")
exp_db=$(date -d "$masaaktif days" +"%Y-%m-%d")
mkdir -p /etc/ssh
echo "#noobz# ${Login} ${Pass} ${Quota} ${iplimit} ${exp_db}" >> /etc/ssh/.ssh.db

# Output Untuk API.JS
clear
echo -e " Remark       : $Login "
echo -e " Password     : $Pass "
echo -e " Limit Ip     : ${iplimit} IP"
echo -e " Limit Quota  : ${Quota} GB"
echo -e " Domain       : $domain "
echo -e " Expiry in    : $exp_db "
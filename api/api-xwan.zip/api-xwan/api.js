const express = require("express");
const { execFile } = require("child_process"); // PERBAIKAN: Gunakan execFile agar aman dari injeksi
const app = express();
const PORT = 5888;

// Middleware untuk parsing query string
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// PERBAIKAN: Fungsi Filter Input (Sanitizer)
// Hanya mengizinkan huruf, angka, strip (-), dan underscore (_).
// Jika ada spasi atau simbol mematikan (; & | ` $), akan otomatis dibuang!
const sanitize = (input) => {
  if (!input) return "";
  return input.toString().replace(/[^a-zA-Z0-9\-_]/g, "");
};

// Fungsi untuk parsing output shell ke JSON
function parseSSHOutput(output) {
  const extract = (pattern) => {
    const match = output.match(pattern);
    return match ? match[1].trim() : "";
  };

  return {
    username: extract(/Remark\s+:\s+(\S+)/),
    password: extract(/Password\s+:\s+(\S+)/),
    ip_limit: extract(/Limit Ip\s+:\s+(.+)/),
    domain: extract(/Domain\s+:\s+(\S+)/),
    ns_domain: extract(/Ns Domain\s+:\s+(.+)/),
    pubkey: extract(/Pub Key\s+:\s+(.+)/),
    isp: extract(/ISP\s+:\s+(.+)/),
    expired: extract(/Expiry in\s+:\s+(.+)/),
    uuid: extract(/Key\s+:\s+(.+)/),
    quota: extract(/Limit Quota\s+:\s+(.+)/),
    vmess_tls_link: extract(/Link TLS\s+:\s+(.+)/),
    vmess_nontls_link: extract(/Link WS\s+:\s+(.+)/),
    vmess_grpc_link: extract(/Link GRPC\s+:\s+(.+)/),
    vless_tls_link: extract(/Link TLS\s+:\s+(.+)/),
    vless_nontls_link: extract(/Link WS\s+:\s+(.+)/),
    vless_grpc_link: extract(/Link GRPC\s+:\s+(.+)/),
    trojan_tls_link: extract(/Link TLS\s+:\s+(.+)/),
    trojan_nontls_link1: extract(/Link WS\s+:\s+(.+)/),
    trojan_grpc_link: extract(/Link GRPC\s+:\s+(.+)/),
    ss_link_nontls: extract(/Link WS\s+:\s+(.+)/),
    ss_link_ws: extract(/Link TLS\s+:\s+(.+)/),
    ss_link_grpc: extract(/Link GRPC\s+:\s+(.+)/),
  };
}

const AUTH_KEY = process.env.AUTH_KEY;

// ================= ROUTE CREATE ACCOUNT =================

app.get("/createssh", (req, res) => {
  let { user, password, exp, iplimit, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !password || !exp || !iplimit)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  // Terapkan Filter
  user = sanitize(user);
  password = sanitize(password);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);

  // PERBAIKAN: Gunakan execFile dengan Array Parameter
  execFile(
    "bash",
    ["create_ssh.sh", user, password, iplimit, exp],
    (error, stdout, stderr) => {
      if (error) return res.json({ status: "error", message: stderr });
      const sshData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Akun SSH berhasil dibuat untuk ${sshData.username}`,
        data: sshData,
      });
    },
  );
});

app.get("/createvmess", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !quota || !iplimit)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["create_vmess.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error) return res.json({ status: "error", message: stderr });
      const vmessData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Akun Vmess berhasil dibuat untuk ${vmessData.username}`,
        data: vmessData,
      });
    },
  );
});

app.get("/createvless", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !quota || !iplimit)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["create_vless.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error) return res.json({ status: "error", message: stderr });
      const vlessData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Akun Vless berhasil dibuat untuk ${vlessData.username}`,
        data: vlessData,
      });
    },
  );
});

app.get("/createtrojan", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !quota || !iplimit)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["create_trojan.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error) return res.json({ status: "error", message: stderr });
      const trojanData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Akun Trojan berhasil dibuat untuk ${trojanData.username}`,
        data: trojanData,
      });
    },
  );
});

app.get("/createshadowsocks", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !quota || !iplimit)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["create_ss.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error) return res.json({ status: "error", message: stderr });
      const shadowsocksData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Akun Shadowsocks berhasil dibuat untuk ${shadowsocksData.username}`,
        data: shadowsocksData,
      });
    },
  );
});

// ================= ROUTE TRIAL ACCOUNT =================

app.get("/trialssh", (req, res) => {
  const { auth } = req.query;
  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });

  execFile("bash", ["trial_ssh.sh"], (error, stdout, stderr) => {
    if (error) return res.json({ status: "error", message: stderr });
    const sshData = parseSSHOutput(stdout);
    res.json({
      status: "success",
      message: `Akun Trial SSH berhasil dibuat untuk ${sshData.username}`,
      data: sshData,
    });
  });
});

app.get("/trialvmess", (req, res) => {
  const { auth } = req.query;
  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });

  execFile("bash", ["trial_vmess.sh"], (error, stdout, stderr) => {
    if (error) return res.json({ status: "error", message: stderr });
    const vmessData = parseSSHOutput(stdout);
    res.json({
      status: "success",
      message: `Akun Trial Vmess berhasil dibuat untuk ${vmessData.username}`,
      data: vmessData,
    });
  });
});

app.get("/trialvless", (req, res) => {
  const { auth } = req.query;
  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });

  execFile("bash", ["trial_vless.sh"], (error, stdout, stderr) => {
    if (error) return res.json({ status: "error", message: stderr });
    const vlessData = parseSSHOutput(stdout);
    res.json({
      status: "success",
      message: `Akun Trial Vless berhasil dibuat untuk ${vlessData.username}`,
      data: vlessData,
    });
  });
});

app.get("/trialtrojan", (req, res) => {
  const { auth } = req.query;
  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });

  execFile("bash", ["trial_trojan.sh"], (error, stdout, stderr) => {
    if (error) return res.json({ status: "error", message: stderr });
    const trojanData = parseSSHOutput(stdout);
    res.json({
      status: "success",
      message: `Akun Trial Trojan berhasil dibuat untuk ${trojanData.username}`,
      data: trojanData,
    });
  });
});

app.get("/trialshadowsocks", (req, res) => {
  const { auth } = req.query;
  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });

  execFile("bash", ["trial_ss.sh"], (error, stdout, stderr) => {
    if (error) return res.json({ status: "error", message: stderr });
    const shadowsocksData = parseSSHOutput(stdout);
    res.json({
      status: "success",
      message: `Akun Trial shadowsocks berhasil dibuat untuk ${shadowsocksData.username}`,
      data: shadowsocksData,
    });
  });
});

// ================= ROUTE RENEW ACCOUNT =================

app.get("/renewssh", (req, res) => {
  let { user, exp, iplimit, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !iplimit)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);

  execFile(
    "sudo",
    ["bash", "/usr/bin/api-xwan/renew_ssh.sh", user, iplimit, exp],
    (error, stdout, stderr) => {
      if (error) {
        console.error("Error:", stderr);
        return res.json({
          status: "error",
          message:
            stdout ||
            stderr ||
            "Gagal memperbarui akun SSH. Pastikan user masih ada.",
        });
      }

      try {
        const sshData = parseSSHOutput(stdout);
        if (!sshData.username)
          return res.status(500).json({
            status: "error",
            message: "Failed to parse renew_ssh.sh output.",
          });

        return res.json({
          status: "success",
          message: `Renew SSH berhasil dibuat untuk ${sshData.username}`,
          data: sshData,
        });
      } catch (e) {
        return res.status(500).json({
          status: "error",
          message: "Internal server error during renew output parsing.",
        });
      }
    },
  );
});

app.get("/renewvmess", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !iplimit || !quota)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["renew_vmess.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error)
        return res.json({
          status: "error",
          message: "Gagal memperbarui akun VMESS. Pastikan user masih ada.",
        });
      const vmessData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Renew Vmess berhasil dibuat untuk ${vmessData.username}`,
        data: vmessData,
      });
    },
  );
});

app.get("/renewvless", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !iplimit || !quota)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["renew_vless.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error)
        return res.json({
          status: "error",
          message: "Gagal memperbarui akun VLESS. Pastikan user masih ada.",
        });
      const vlessData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Renew Vless berhasil dibuat untuk ${vlessData.username}`,
        data: vlessData,
      });
    },
  );
});

app.get("/renewtrojan", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !iplimit || !quota)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["renew_trojan.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error)
        return res.json({
          status: "error",
          message: "Gagal memperbarui akun TROJAN. Pastikan user masih ada.",
        });
      const trojanData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Renew Trojan berhasil dibuat untuk ${trojanData.username}`,
        data: trojanData,
      });
    },
  );
});

app.get("/renewshadowsocks", (req, res) => {
  let { user, exp, iplimit, quota, auth } = req.query;

  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !exp || !iplimit || !quota)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota);

  execFile(
    "bash",
    ["renew_ss.sh", user, exp, iplimit, quota],
    (error, stdout, stderr) => {
      if (error)
        return res.json({
          status: "error",
          message:
            "Gagal memperbarui akun Shadowsocks. Pastikan user masih ada.",
        });
      const shadowsocksData = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Renew Shadowsocks berhasil dibuat untuk ${shadowsocksData.username}`,
        data: shadowsocksData,
      });
    },
  );
});

// ================= ROUTE NOOBZVPN =================
app.get("/createnoobz", (req, res) => {
  let { user, password, exp, iplimit, quota, auth } = req.query;
  if (!AUTH_KEY)
    return res
      .status(500)
      .json({ status: "error", message: "AUTH_KEY not set" });
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  if (!user || !password || !exp || !iplimit)
    return res
      .status(400)
      .json({ status: "error", message: "Missing parameters" });

  user = sanitize(user);
  password = sanitize(password);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  quota = sanitize(quota) || "0";
  execFile(
    "bash",
    ["create_noobz.sh", user, password, iplimit, exp, quota],
    (error, stdout, stderr) => {
      if (error) return res.json({ status: "error", message: stderr });
      const data = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Akun NOOBZ berhasil dibuat untuk ${data.username}`,
        data: data,
      });
    },
  );
});

app.get("/trialnoobz", (req, res) => {
  const { auth } = req.query;
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  execFile("bash", ["trial_noobz.sh"], (error, stdout, stderr) => {
    if (error) return res.json({ status: "error", message: stderr });
    const data = parseSSHOutput(stdout);
    res.json({
      status: "success",
      message: `Trial NOOBZ berhasil dibuat untuk ${data.username}`,
      data: data,
    });
  });
});

app.get("/renewnoobz", (req, res) => {
  let { user, exp, iplimit, auth } = req.query;
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  execFile(
    "bash",
    ["renew_noobz.sh", user, exp, iplimit],
    (error, stdout, stderr) => {
      if (error)
        return res.json({ status: "error", message: "Gagal renew NOOBZ." });
      res.json({
        status: "success",
        message: `Renew NOOBZ berhasil untuk ${user}`,
        data: parseSSHOutput(stdout),
      });
    },
  );
});

// ================= ROUTE ZIVPN =================
app.get("/createzivpn", (req, res) => {
  let { user, password, exp, iplimit, auth } = req.query;
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  user = sanitize(user);
  password = sanitize(password);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  execFile(
    "bash",
    ["create_zivpn.sh", user, password, iplimit, exp],
    (error, stdout, stderr) => {
      if (error) return res.json({ status: "error", message: stderr });
      const data = parseSSHOutput(stdout);
      res.json({
        status: "success",
        message: `Akun ZIVPN berhasil dibuat untuk ${data.username}`,
        data: data,
      });
    },
  );
});

app.get("/trialzivpn", (req, res) => {
  const { auth } = req.query;
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  execFile("bash", ["trial_zivpn.sh"], (error, stdout, stderr) => {
    if (error) return res.json({ status: "error", message: stderr });
    const data = parseSSHOutput(stdout);
    res.json({
      status: "success",
      message: `Trial ZIVPN berhasil dibuat untuk ${data.username}`,
      data: data,
    });
  });
});

app.get("/renewzivpn", (req, res) => {
  let { user, exp, iplimit, auth } = req.query;
  if (auth !== AUTH_KEY)
    return res.status(403).json({ status: "error", message: "Unauthorized" });
  user = sanitize(user);
  exp = sanitize(exp);
  iplimit = sanitize(iplimit);
  execFile(
    "bash",
    ["renew_zivpn.sh", user, exp, iplimit],
    (error, stdout, stderr) => {
      if (error)
        return res.json({ status: "error", message: "Gagal renew ZIVPN." });
      res.json({
        status: "success",
        message: `Renew ZIVPN berhasil untuk ${user}`,
        data: parseSSHOutput(stdout),
      });
    },
  );
});

// Menjalankan server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server berjalan di port ${PORT} - Secure Mode ON`);
});

#!/bin/bash
# ==========================================
# Script API Renew Trojan | Smart DB
# ==========================================

user=$1
masaaktif=$2
iplimit=$3
Quota=$4

# --- BAGIAN BYPASS LISENSI ---
checking_sc() {
    echo "License ByPass... SUCCESS!"
}
checking_sc
# -----------------------------

# Cek apakah user ada di database Smart DB
check_user=$(grep -wE "^#! $user" "/etc/trojan/.trojan.db" | head -n1)

if [[ -z "$check_user" ]]; then
    echo -e "User $user Tidak Ditemukan!!"
    exit 1
fi

# Ambil data lama dari Database
exp=$(echo "$check_user" | awk '{print $3}')
uuid=$(echo "$check_user" | awk '{print $4}')
Old_Quota=$(echo "$check_user" | awk '{print $5}')

# Jika Kuota tidak dikirim via API, gunakan Kuota lama
if [[ -z "$Quota" || "$Quota" == "undefined" ]]; then
    Quota=$Old_Quota
fi

# ================= KALKULASI TANGGAL EXPIRED =================
now=$(date +%Y-%m-%d)
d1=$(date -d "$exp" +%s)
d2=$(date -d "$now" +%s)

# Jika akun sudah expired, hitung masa aktif dari hari ini
if [[ $d1 -lt $d2 ]]; then
    exp4=$(date -d "$now + $masaaktif days" +"%Y-%m-%d")
else
    # Jika masih aktif, tambahkan dari sisa hari
    exp4=$(date -d "$exp + $masaaktif days" +"%Y-%m-%d")
fi

# ================= UPDATE LIMIT IP & QUOTA =================
# Update Limit IP
if [[ $iplimit -gt 0 ]]; then
    mkdir -p /etc/kyt/limit/trojan/ip
    echo -e "$iplimit" > /etc/kyt/limit/trojan/ip/$user
fi

# Update Quota
if [ -z "$Quota" ]; then Quota="0"; fi
c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))

mkdir -p /etc/trojan
if [[ ${c} != "0" ]]; then
    echo "${d}" >/etc/trojan/${user}
fi

# ================= UPDATE CONFIG & DATABASE =================
# Update Config Xray (Mengganti tanggal di tag #!)
sed -i "s/#! $user $exp/#! $user $exp4/g" /etc/xray/config.json

# Update Database Utama (Hapus data lama, tulis yang baru)
sed -i "/^#! $user /d" /etc/trojan/.trojan.db
echo "#! $user $exp4 $uuid $Quota $iplimit" >> /etc/trojan/.trojan.db

systemctl restart xray > /dev/null 2>&1

# ================= NOTIFIKASI TELEGRAM =================
function notif_renew_trojan() {
    CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 3)
    KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 2)
    export TIME="10"
    export URL="https://api.telegram.org/bot$KEY/sendMessage"
    
    if [[ -n "$KEY" && -n "$CHATID" ]]; then
        TEXT="<b>======================</b>
<b>RENEW TROJAN API SUCCESS</b>
<b>======================</b>
<b>» Username :</b> <code>${user}</code>
<b>» Renew :</b> <code>${masaaktif} Days</code>
<b>» New Quota :</b> <code>${Quota} GB</code>
<b>» New IP Limit:</b> <code>${iplimit} Device</code>
<b>» New Expired:</b> <code>${exp4}</code>
<b>======================</b>"
        curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" "$URL" >/dev/null
    fi
}
notif_renew_trojan

# ================= OUTPUT UNTUK API.JS =================
# (JANGAN MENGUBAH TEKS SEBELAH KIRI AGAR PARSING REGEX API.JS TIDAK ERROR)
clear
echo -e " RENEW TROJAN"
echo -e " Remark       : $user "
echo -e " Limit Ip     : ${iplimit}"
echo -e " Limit Quota  : ${Quota} GB"
echo -e " Expiry in    : $exp4 "
exit 0
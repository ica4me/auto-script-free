#!/bin/bash
# ==========================================
# Script API Create VMESS | Smart DB & Anti-Crash
# ==========================================

Login=$1
masaaktif=$2
iplimit=$3
Quota=$4

# Generate Username Acak (Prefix + 3 Karakter)
user="${Login}VM$(</dev/urandom tr -dc A-Z0-9 | head -c3)"
IP=$(curl -sS ipv4.icanhazip.com 2>/dev/null)

# --- BAGIAN BYPASS START ---
checking_sc() {
    echo "License ByPass... SUCCESS!"
}
checking_sc
# --- BAGIAN BYPASS END ---

ISP=$(cat /etc/xray/isp 2>/dev/null)
CITY=$(cat /etc/xray/city 2>/dev/null)
domain=$(cat /etc/xray/domain 2>/dev/null)
uuid=$(cat /proc/sys/kernel/random/uuid)

tgl=$(date -d "$masaaktif days" +"%d")
bln=$(date -d "$masaaktif days" +"%b")
thn=$(date -d "$masaaktif days" +"%Y")
expe="$tgl $bln, $thn"
tgl2=$(date +"%d")
bln2=$(date +"%b")
thn2=$(date +"%Y")
tnggl="$tgl2 $bln2, $thn2"
exp=$(date -d "$masaaktif days" +"%Y-%m-%d")

# ================= INJEKSI CONFIG XRAY (SMART DB) =================
# Menggunakan Tag ### untuk VMess dan format email vmess-$user
sed -i '/#vmess$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": 0,"email": "vmess-'"$user"'"}' /etc/xray/config.json

sed -i '/#vmessgrpc$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": 0,"email": "vmess-'"$user"'"}' /etc/xray/config.json

# ================= GENERATE LINK (BUG FIXED) =================
asu=$(cat<<EOF
{
  "v": "2",
  "ps": "${user}",
  "add": "${domain}",
  "port": "443",
  "id": "${uuid}",
  "aid": "0",
  "net": "ws",
  "path": "/vmess",
  "type": "none",
  "host": "${domain}",
  "tls": "tls"
}
EOF
)
ask=$(cat<<EOF
{
  "v": "2",
  "ps": "${user}",
  "add": "${domain}",
  "port": "80",
  "id": "${uuid}",
  "aid": "0",
  "net": "ws",
  "path": "/vmess",
  "type": "none",
  "host": "${domain}",
  "tls": "none"
}
EOF
)
grpc=$(cat<<EOF
{
  "v": "2",
  "ps": "${user}",
  "add": "${domain}",
  "port": "443",
  "id": "${uuid}",
  "aid": "0",
  "net": "grpc",
  "path": "vmess-grpc",
  "type": "none",
  "host": "${domain}",
  "tls": "tls"
}
EOF
)

vmesslink1="vmess://$(echo -n "$asu" | base64 -w 0)"
vmesslink2="vmess://$(echo -n "$ask" | base64 -w 0)"
vmesslink3="vmess://$(echo -n "$grpc" | base64 -w 0)"

# ================= FORMAT OPENCLASH =================
mkdir -p /var/www/html
cat >/var/www/html/vmess-$user.txt <<-END
-----------------------------------------
Format Open Clash
-----------------------------------------
- name: Vmess-$user-WS TLS
  type: vmess
  server: ${domain}
  port: 443
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

- name: Vmess-$user-WS Non TLS
  type: vmess
  server: ${domain}
  port: 80
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: false
  skip-cert-verify: false
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: ${domain}

- name: Vmess-$user-gRPC (SNI)
  server: ${domain}
  port: 443
  type: vmess
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  network: grpc
  tls: true
  servername: ${domain}
  skip-cert-verify: true
  grpc-opts:
    grpc-service-name: vmess-grpc
-----------------------------------------
Link Akun Vmess                   
-----------------------------------------
Link TLS         : 
${vmesslink1}
-----------------------------------------
Link none TLS    : 
${vmesslink2}
-----------------------------------------
Link GRPC        : 
${vmesslink3}
-----------------------------------------
Expired          : $expe
-----------------------------------------
END

# ================= LIMIT QUOTA & IP =================
if [[ $iplimit -gt 0 ]]; then
    mkdir -p /etc/kyt/limit/vmess/ip
    echo -e "$iplimit" > /etc/kyt/limit/vmess/ip/$user
fi

if [ -z ${Quota} ]; then Quota="0"; fi
c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))
mkdir -p /etc/vmess

if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/vmess/${user}
fi

# ================= SAVE TO DATABASE =================
sed -i "/\b${user}\b/d" /etc/vmess/.vmess.db 2>/dev/null
echo "### ${user} ${exp} ${uuid} ${Quota} ${iplimit}" >> /etc/
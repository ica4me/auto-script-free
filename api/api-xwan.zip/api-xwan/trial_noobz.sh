#!/bin/bash
pup="30"
iplimit="1"
Login="TrialNBZ$(</dev/urandom tr -dc A-Z0-9 | head -c3)"
Pass=$(</dev/urandom tr -dc a-zA-Z0-9 | head -c5)
domain=$(cat /etc/xray/domain 2>/dev/null)

if ! grep -q "/bin/false" /etc/shells; then echo "/bin/false" >> /etc/shells; fi
useradd -e $(date -d "1 days" +"%Y-%m-%d") -s /bin/false -M $Login
echo "$Login:$Pass" | chpasswd

if command -v noobzvpns &> /dev/null; then
    noobzvpns --add-user $Login $Pass --expired-user $Login 1
fi

# Background Auto-Killer Clean Wipe
(
    sleep $((pup * 60))
    userdel -f "$Login" >/dev/null 2>&1
    if command -v noobzvpns &> /dev/null; then
        noobzvpns --remove-user $Login
    fi
) &

clear
echo -e " Remark       : $Login "
echo -e " Password     : $Pass "
echo -e " Limit Ip     : ${iplimit} IP"
echo -e " Domain       : $domain "
echo -e " Expiry in    : $pup Minutes "
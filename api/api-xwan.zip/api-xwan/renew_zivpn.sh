#!/bin/bash
username=$1
duration=$2
iplimit=$3

USER_DB="/etc/zivpn/users.db.json"
if ! jq -e --arg user "$username" '.[] | select(.username == $user)' "$USER_DB" > /dev/null; then exit 1; fi

# Edit JSON Timestamp
new_expiry_timestamp=$(date -d "+$duration days" +%s)
exp_db=$(date -d "@$new_expiry_timestamp" '+%Y-%m-%d')

jq --arg user "$username" --argjson new_expiry "$new_expiry_timestamp" \
    '(.[] | select(.username == $user) | .expiry_timestamp) = $new_expiry | del(.[] | select(.username == $user) | .expiry_date)' \
    "$USER_DB" > "$USER_DB.tmp" && mv "$USER_DB.tmp" "$USER_DB"

clear
echo -e " Remark       : $username "
echo -e " Limit Ip     : ${iplimit}"
echo -e " Expiry in    : $exp_db "
#!/bin/bash
user=$1
masaaktif=$2
iplimit=$3

# Cek Database
check_user=$(grep -wE "^#noobz# $user" "/etc/ssh/.ssh.db" | head -n1)
if [[ -z "$check_user" ]]; then exit 1; fi

exp=$(echo "$check_user" | awk '{print $6}')
now=$(date +%s)
d1=$(date -d "$exp" +%s)

if [[ $d1 -lt $now ]]; then
    exp4=$(date -d "+$masaaktif days" +"%Y-%m-%d")
else
    exp4=$(date -d "$exp +$masaaktif days" +"%Y-%m-%d")
fi

# Renew OS & Noobz
usermod -e $exp4 $user &>/dev/null
passwd -u $user &>/dev/null 
if command -v noobzvpns &> /dev/null; then
    noobzvpns --renew-user $user $masaaktif
fi

# Update DB
sed -i "s/#noobz# $user .*/#noobz# $user $(echo "$check_user" | awk '{print $3}') $(echo "$check_user" | awk '{print $4}') $iplimit $exp4/g" /etc/ssh/.ssh.db

clear
echo -e " Remark       : $user "
echo -e " Limit Ip     : ${iplimit}"
echo -e " Expiry in    : $exp4 "
#!/bin/bash
# ==========================================
# Script API Create Trojan | Smart DB & Anti-Crash
# ==========================================

Login=$1
masaaktif=$2
iplimit=$3
Quota=$4

# Generate Username Acak (Prefix + 3 Karakter)
user="${Login}TR$(</dev/urandom tr -dc A-Z0-9 | head -c3)"
IP=$(curl -sS ipv4.icanhazip.com 2>/dev/null)

# --- BAGIAN BYPASS START ---
checking_sc() {
    echo "License ByPass... SUCCESS!"
}
checking_sc
# --- BAGIAN BYPASS END ---

ISP=$(cat /etc/xray/isp 2>/dev/null)
CITY=$(cat /etc/xray/city 2>/dev/null)
domain=$(cat /etc/xray/domain 2>/dev/null)
uuid=$(cat /proc/sys/kernel/random/uuid)

tgl=$(date -d "$masaaktif days" +"%d")
bln=$(date -d "$masaaktif days" +"%b")
thn=$(date -d "$masaaktif days" +"%Y")
expe="$tgl $bln, $thn"
tgl2=$(date +"%d")
bln2=$(date +"%b")
thn2=$(date +"%Y")
tnggl="$tgl2 $bln2, $thn2"
exp=$(date -d "$masaaktif days" +"%Y-%m-%d")

# ================= INJEKSI CONFIG XRAY (SMART DB) =================
# Menggunakan Tag #! untuk Trojan dan format email trojan-$user
sed -i '/#trojanws$/a\#! '"$user $exp"'\
},{"password": "'""$uuid""'","email": "trojan-'"$user"'"}' /etc/xray/config.json

sed -i '/#trojangrpc$/a\#! '"$user $exp"'\
},{"password": "'""$uuid""'","email": "trojan-'"$user"'"}' /etc/xray/config.json

# ================= GENERATE LINK =================
# Menggunakan ${domain} dinamis
trojanlink1="trojan://${uuid}@${domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni=${domain}#${user}"
trojanlink="trojan://${uuid}@${domain}:443?path=%2Ftrojan-ws&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"
trojanlink2="trojan://${uuid}@${domain}:80?path=%2Ftrojan-ws&security=none&host=${domain}&type=ws#${user}"

# ================= FORMAT OPENCLASH =================
mkdir -p /var/www/html
cat >/var/www/html/trojan-$user.txt <<-END
-----------------------------------------
Format Open Clash
-----------------------------------------
- name: Trojan-$user-GO/WS
  server: ${domain}
  port: 443
  type: trojan
  password: ${uuid}
  network: ws
  sni: ${domain}
  skip-cert-verify: true
  udp: true
  ws-opts:
    path: /trojan-ws
    headers:
        Host: ${domain}

- name: Trojan-$user-gRPC
  type: trojan
  server: ${domain}
  port: 443
  password: ${uuid}
  udp: true
  sni: ${domain}
  skip-cert-verify: true
  network: grpc
  grpc-opts:
    grpc-service-name: trojan-grpc

-----------------------------------------
Link Akun Trojan 
-----------------------------------------
Link WS          : 
${trojanlink}
-----------------------------------------
Link GRPC        : 
${trojanlink1}
-----------------------------------------
Expired          : $expe
-----------------------------------------
END

# ================= LIMIT QUOTA & IP =================
if [[ $iplimit -gt 0 ]]; then
    mkdir -p /etc/kyt/limit/trojan/ip
    echo -e "$iplimit" > /etc/kyt/limit/trojan/ip/$user
fi

if [ -z ${Quota} ]; then Quota="0"; fi
c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))
mkdir -p /etc/trojan

if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/trojan/${user}
fi

# ================= SAVE TO DATABASE =================
sed -i "/\b${user}\b/d" /etc/trojan/.trojan.db 2>/dev/null
echo "#! ${user} ${exp} ${uuid} ${Quota} ${iplimit}" >> /etc/trojan/.trojan.db

systemctl restart xray > /dev/null 2>&1

# ================= NOTIFIKASI TELEGRAM =================
function notif_trojan() {
    CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 3)
    KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 2)
    export TIME="10"
    export URL="https://api.telegram.org/bot$KEY/sendMessage"
    sensor=$(echo "$user" | sed 's/\(.\{3\}\).*/\1xxx/')
    
    if [[ -n "$KEY" && -n "$CHATID" ]]; then
        TEXT="<b>======================</b>
<b>PREMIUM TROJAN GENERATED API</b>
<b>======================</b>
<b>» ISP :</b> <code>${ISP}</code>
<b>» Limit Quota :</b> <code>${Quota} GB</code>
<b>» Limit Login :</b> <code>${iplimit} Device</code>
<b>» Username :</b> <code>${sensor}</code>
<b>» Duration :</b> <code>${masaaktif} Days</code>
<b>======================</b>"
        curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" "$URL" >/dev/null
    fi
}
notif_trojan

# ================= OUTPUT UNTUK API.JS =================
# (JANGAN MENGUBAH TEKS SEBELAH KIRI AGAR PARSING REGEX API.JS TIDAK ERROR)
echo -e " Remark       : ${user}"
echo -e " Domain       : ${domain}"
echo -e " Limit Quota  : ${Quota} GB"
echo -e " Limit Ip     : ${iplimit}"
echo -e " Port TLS     : 400,8443"
echo -e " port WS      : 80,8880,8080,2082"
echo -e " Key          : ${uuid}"
echo -e " Localtions   : $CITY"
echo -e " ISP          : $ISP"
echo -e " AlterId      : 0"
echo -e " Security     : auto"
echo -e " Network      : ws"
echo -e " Path         : /trojan-ws"
echo -e " ServiceName  : trojan-grpc"
echo -e " Link TLS     : ${trojanlink}"
echo -e " Link WS      : ${trojanlink2}"
echo -e " Link GRPC    : ${trojanlink1}"
echo -e " Expiry in    : $expe "
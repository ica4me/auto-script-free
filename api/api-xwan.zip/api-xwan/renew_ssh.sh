#!/bin/bash
# ==========================================
# Script API Renew SSH | Smart DB
# ==========================================

user=$1
iplimit=$2
masaaktif=$3
Quota=$4 # Optional, untuk persiapan jika API mendukung update kuota

# --- BAGIAN BYPASS LISENSI ---
checking_sc() {
    echo "License ByPass... SUCCESS!"
}
checking_sc
# -----------------------------

# Cek OS User
if ! id "$user" &>/dev/null; then
    echo "RENEW SSH GAGAL: User $user tidak ditemukan"
    exit 1
fi

# Cek keberadaan user di Smart DB
check_user=$(grep -wE "^#ssh# $user" "/etc/ssh/.ssh.db" | head -n1)
if [[ -z "$check_user" ]]; then
    echo "RENEW SSH GAGAL: User $user tidak ada di database"
    exit 1
fi

Pass=$(echo "$check_user" | awk '{print $3}')
Old_Quota=$(echo "$check_user" | awk '{print $4}')

# Jika Kuota tidak dikirim via API, gunakan Kuota lama
if [[ -z "$Quota" ]]; then
    Quota=$Old_Quota
fi

# ================= KALKULASI TANGGAL EXPIRED =================
current_exp=$(chage -l "$user" | grep "Account expires" | cut -d: -f2 | xargs)
now=$(date +%s)

if [[ "$current_exp" == "never" ]] || [[ -z "$current_exp" ]]; then
    d1=$now
else
    d1=$(date -d "$current_exp" +%s)
fi

# Jika akun sudah expired, hitung masa aktif dari hari ini
if [[ $d1 -lt $now ]]; then
    exp4=$(date -d "+$masaaktif days" +"%Y-%m-%d")
else
    # Jika masih aktif, tambahkan dari sisa hari
    exp4=$(date -d "$current_exp +$masaaktif days" +"%Y-%m-%d")
fi

# ================= UPDATE OS USER =================
usermod -e $exp4 $user &>/dev/null
passwd -u $user &>/dev/null # Membuka gembok jika akun sempat terkunci

# ================= UPDATE LIMIT IP & QUOTA =================
if [[ $iplimit -gt 0 ]]; then
    mkdir -p /etc/kyt/limit/ssh/ip
    echo -e "$iplimit" > /etc/kyt/limit/ssh/ip/$user
fi

c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
if [[ -n "$c" && "$c" != "0" ]]; then
    d=$((${c} * 1024 * 1024 * 1024))
    mkdir -p /etc/ssh
    echo "${d}" > /etc/ssh/${user}
fi

# ================= UPDATE DATABASE =================
sed -i "/^#ssh# $user /d" /etc/ssh/.ssh.db
echo "#ssh# $user $Pass $Quota $iplimit $exp4" >> /etc/ssh/.ssh.db

# ================= NOTIFIKASI TELEGRAM =================
function notif_renew_ssh() {
    CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 3)
    KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" 2>/dev/null | cut -d ' ' -f 2)
    export TIME="10"
    export URL="https://api.telegram.org/bot$KEY/sendMessage"
    
    if [[ -n "$KEY" && -n "$CHATID" ]]; then
        TEXT="<b>======================</b>
<b>RENEW SSH API SUCCESS</b>
<b>======================</b>
<b>» Username :</b> <code>${user}</code>
<b>» Renew :</b> <code>${masaaktif} Days</code>
<b>» Limit Quota :</b> <code>${Quota} GB</code>
<b>» Limit Login :</b> <code>${iplimit} Device</code>
<b>» New Expired :</b> <code>${exp4}</code>
<b>======================</b>"
        curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" "$URL" >/dev/null
    fi
}
notif_renew_ssh

# ================= OUTPUT UNTUK API.JS =================
# (JANGAN MENGUBAH TEKS SEBELAH KIRI AGAR PARSING REGEX API.JS TIDAK ERROR)
clear
echo -e " RENEW SSH ACCOUNT"
echo -e " Remark       : ${user}"
echo -e " Limit Ip     : ${iplimit}"
echo -e " Limit Quota  : ${Quota} GB"
echo -e " Expiry in    : ${exp4}"
exit 0